package install

//SdosInstaller is
type SdosInstaller struct {
	Nodes     []string
}

