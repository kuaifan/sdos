package install

type SdosConfig struct {
	Nodes   []string
}