package version

var (
	// Version is the current File Browser version.
	Version = "(untracked)"
	// CommitSHA is the commmit sha.
	CommitSHA = "(unknown)"
)
